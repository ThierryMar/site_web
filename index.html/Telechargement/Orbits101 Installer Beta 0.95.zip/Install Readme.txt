Orbits101 Installation
----------------------

Version: Beta 0.95, 2026-08-28

0) Unzip file "Orbits101 Installer Beta 0.95.zip" to a temporary folder

1) Run insaller "Orbits101 Installer.exe" and follow instructions (select [v] Add shortcut to desktiop)

    Select destination folder: e.g. C:\Program Files\Orbits101  or D:\MyFiles\Orbits101  (do not change name "Orbits101")

    The first time, a MATLAB Runtime Package will automatically be downloaded and it will take a few minutes to install.
		C:\Program Files\MATLAB\MATLAB Runtime\R2025b → ≈ 3 GB

    VIRUS WARNING → Ignore
    False Positive ; The official MathWorks tools and generated binaries are safe. 

    The Trojan/Bearfoos.A!ml warning on MATLAB compiled code (.exe or .dll) is a known false positive triggered by 
    machine-learning-based antivirus software (like Windows Defender, Avast, or Malwarebytes). It happens because 
    MATLAB wraps compiled applications in a way that mimics malware behavior. MathWorks +3

    How to Resolve the False Positive
    Exclude File/Folder: In your antivirus settings (e.g., Windows Security > Virus & threat protection > 
    Manage settings > Exclusions), add the folder containing your compiled MATLAB application to the exclusion list.
    Restore from Quarantine: If the file was moved to quarantine, navigate to your antivirus's "Quarantine" or
    "Threat History" area and restore the file.
    Submit as False Positive: Submit the flagged file to your antivirus provider for analysis so they can update their
    definitions.
    Verify with VirusTotal: Upload the executable to VirusTotal to check if other engines confirm it as a false
    positive.

    Why This Happens
    Machine Learning (ML) Detection: The !ml tag indicates that AI-based scanners are flagging the code based on 
    heuristics, not a known virus signature.
    Compiled Structure: MATLAB compiles code into a bundle, often creating packed or encrypted files that security 
    software perceives as suspicious, particularly with newer R2022b+ versions.
    Dependency Files: Sometimes specific DLLs, such as libmwtester_core_mi.dll or mwdocsearch.exe, are mistakenly 
    targeted. The Rust Programming Language 

2) Copy folder "SPACE" into (install dir)\Orbits101\application

3) Give access (install dir)\Orbits101 to allow downloading EOP and Space-Track latest data.
	Select Orbits101 folder (e.g. C:\Program Files\Orbits101)
	Right-click: Properties > Security > Edit: Users → Full control
	
	Initial versions of the files eop19620101.txt (for EOP Data) and Space-Track Full Catalog 3LE (YYYY-MM-DD).txt are provided the DATA folder; 
	these files can be updated by Orbits101 by clicking [Update TLE Database] in the Demo NORAD Name/#, which downloads from the Internet the 
	latest versions of the files.
	

4) IMP: The app is designed for a minimum 1920 x 1080 pixel screen.

   At this resolution, if your Windows Display Settings > Scale & layout is larger than 100%, the application 
   figure and buttons might appear displaced or crammed together.
   In this case, either set scale back to 100% (or any value that allows showing all buttons) while using the app, 
   or use another screen with larger resolution.
   (the app might automatically move itself to the highest resolution screen if more than one screen is present)

5) Run the app Orbits101.exe
   IMP: Wait between 30 sec to 1 minute on some computers while the app loads from Internet EOP data, is fully loaded and set to the actual screen.

For any question or bug report, please contact me at RLLac@Ulaval.ca

